#include "PhoneDir.h"
int main(void)
{
    /* Driver Program */
    
    PhoneDir celebrityDir;
    celebrityDir.addNew("Elon Musk","000");
    celebrityDir.addNew("Matt Damon","001");
    celebrityDir.addNew("Jeff Bezos","002");

    PhoneDir gtuDir;
    gtuDir.addNew("Nevzat Seferoglu","004");

    PhoneDir newDir = gtuDir + celebrityDir;
    newDir.showDir();

    
    gtuDir = celebrityDir;
    gtuDir.showDir();

    return 0;
}