#include <iostream>
#include <string>

using std::cout;
using std::cin;
using std::cerr;
using std::endl;
using std::string;

class PhoneDir{
    public:
        PhoneDir(); 
        PhoneDir(const PhoneDir& other);
        PhoneDir(int capacity);
        ~PhoneDir();
        
        const string& operator[](const int& index) const;
        string& operator[](const int& index);
        
        const PhoneDir operator+(const PhoneDir& other) const;
        void operator+=(const PhoneDir& other);
        PhoneDir operator=(const PhoneDir& other);

        bool isInDirectory(string name) const;
        bool addNew(string name,string number);
        int getNameNum(void) const;
        void showDir(void) const;
    private:
        string* name;
        string* number;
        int capacity;
        int used;
};