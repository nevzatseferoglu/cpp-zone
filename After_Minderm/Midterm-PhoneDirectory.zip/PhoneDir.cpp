#include "PhoneDir.h"

PhoneDir::PhoneDir()
{
    capacity = 50;
    used = 0;

    name = new string[capacity];
    if(name == nullptr)
    {
        cerr << "Allocation Error !" << endl;
        exit(0);
    }

    number = new string[capacity];
    if(number == nullptr)
    {
        cerr << "Allocation Error !" << endl;
        exit(0);
    }
}
PhoneDir::PhoneDir(const PhoneDir& other)
{
    name = new string[other.capacity];
    if(name == nullptr)
    {
        cerr << "Allocation Error !" << endl;
        exit(0);
    }

    number = new string[other.capacity];
    if(number == nullptr)
    {
        cerr << "Allocation Error !" << endl;
        exit(0);
    }

    capacity = other.capacity;
    used = other.used;
    
    for(int i = 0 ; i < capacity ; ++i)
    {
        name[i] = other.name[i];
        number[i] = other.number[i];
    }

}
PhoneDir::PhoneDir(int capacity)
{
    this->capacity = capacity;
    used = 0;

    name = new string[this->capacity];
    if(name == nullptr)
    {
        cerr << "Allocation Error !" << endl;
        exit(0);
    }
    
    number = new string[this->capacity];
    if(number == nullptr)
    {
        cerr << "Allocation Error !" << endl;
        exit(0);
    }
}
bool PhoneDir::addNew(string name,string number)
{
    if(!isInDirectory(name) && used <= capacity)
    {
        this->name[used] = name;
        this->number[used] = number;
        ++used;

        return true;
    }
    else
        return false;
}
const PhoneDir PhoneDir::operator+(const PhoneDir& other) const
{
    PhoneDir newDir(capacity+other.capacity);

    for(int i = 0 ; i < capacity ; ++i)
        newDir.addNew(name[i],number[i]);
    
    for(int i = 0 ; i < other.capacity ; ++i){
        if(!isInDirectory(other.name[i]))
            newDir.addNew(other.name[i],other.number[i]);
    }

    return newDir;
}
void PhoneDir::operator+=(const PhoneDir& other)
{
    capacity += other.capacity;

    for(int i = 0 ; i < other.capacity ; ++i )
        if( !isInDirectory(other.name[i]) )
            addNew(other.name[i],other.number[i]);
}
bool PhoneDir::isInDirectory(string name) const
{
    for(int i = 0; i < capacity ; ++i)
        if(this->name[i] == name)
            return true;
    return false;
}
void PhoneDir::showDir(void) const
{
    for(int i = 0 ; i < used ; ++i)
        cout << name[i] << " " << number[i] << endl;
}
PhoneDir::~PhoneDir()
{
    delete [] name;
    delete [] number;    
}
const string& PhoneDir::operator[](const int& index) const
{
    if(index < 0 || index > used - 1)
    {
        cerr << "Wrong typed index number !" << endl;
        exit(0);
    }
    return name[index];
} 
string& PhoneDir::operator[](const int& index)
{
    if(index < 0 || index > used - 1 || used == 0){
        cerr << "Wrong typed index number !" << endl;
        exit(0);
    }
    return name[index];
}
int PhoneDir::getNameNum(void) const
{
    return used;
}
PhoneDir PhoneDir::operator=(const PhoneDir& other)
{
    if( &other == this )
        return *this;

    delete [] name;
    delete [] number;
    
    capacity = other.capacity;
    used = other.used;

    name = new string[capacity];
    number = new string[capacity];


    for(int i = 0 ; i < other.capacity ; ++i)
        addNew(other.name[i],other.number[i]);

    return *this;
}